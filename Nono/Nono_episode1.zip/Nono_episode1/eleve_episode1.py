#=======================================================================
# fichier : eleve_episode1.py
# but     : le programme du robot
# auteur  :
# date    :
#=======================================================================

######### Importations de modules ######################################
from robot import *
from exercice1 import *

# Changer ici le numéro de mission
NUM_EXO = 1

######### Les fonctions de l'utilisateur ###############################
def mission1():
    # à modifier et compléter
    pass

# Ajouter les fonctions suivantes en les numérotant

######### PROGRAMME PRINCIPAL ##########################################
demarrer(NUM_EXO)

# Changer le numéro au fur et à mesure de l'avancement des missions
mission1()

verifier(NUM_EXO)

